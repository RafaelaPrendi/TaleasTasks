# TaleasTask1-Crud
Demo of task1

To run:
1. Install NodeJs (stable version)
2. Download this git repository by git clone or by ZIP (click at the GREEN BUTTON named Code and options will show)
3. Open folder
4. Open terminal in folder (in windows you can open it by SHIFT + RIGHT CLICK => open powershell)
5. 'npm install' + enter
6. 'npm start' + enter
7. use postman to send get/post requests
