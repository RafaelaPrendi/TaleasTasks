const mongoose = require('mongoose')

// const enrollmentSchema = mongoose.Schema({
//     student: {
//         type: mongoose.Schema.Types.ObjectId,
//         ref: 'Student'
//     },
//     course: {
//         type: mongoose.Schema.Types.ObjectId,
//         ref: 'Course'
//     },
// }, { collection: "enrollments" });
// module.exports = mongoose.model('Enrollment', enrollmentSchema);